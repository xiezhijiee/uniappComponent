<template>
	<view class="">
		第三个页面
	</view>
</template>

<script>
</script>

<style>
</style>
