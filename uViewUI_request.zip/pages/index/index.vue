<template>
	<view class="content">
		<button type="default" class="buttn" @click="request"> 点击请求</button>
		<view class="">
			{{value}}
		</view>
		</view>
</template>

<script>
export default {
	data() {
		return {
			value:''
		};
	},
	onLoad() {},
	methods: {
		request() {
			
			// this.$u.api.getTest().then(res=>{
			// 	console.log(res)
			// })
			
		}
	}
};
</script>

<style>
.content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 100vh;
	width: 100vw;
}
.buttn{
}
</style>
