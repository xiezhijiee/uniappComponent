const test = ''

const install = (Vue, vm) => {
	const creatPostApi=(path)=>{
		return (params={})=>vm.$u.http.post(path,params)
	}
	const creatGetApi=(path)=>{
		return (params={})=>vm.$u.http.get (path,params)
	}
	
	const getTest = creatGetApi(test);
	
	vm.$u.api = { //暴露出去方法
		getTest
	}
}

export default {
	install
}
