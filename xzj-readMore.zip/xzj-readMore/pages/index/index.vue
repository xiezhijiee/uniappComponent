<template>
	<view class="main">
		<!-- showHeight 这里的值是rpx -->
		<xzj-readMore hideLineNum="4" showHeight="100">
			（这里超出了设置的高度所以显示了查看更多）
			人之初，性本善。性相近，习相远。
			苟不教，性乃迁。教之道，贵以专。
			昔孟母，择邻处。子不学，断机杼。
			窦燕山，有义方。教五子，名俱扬。
			养不教，父之过。教不严，师之惰。
		</xzj-readMore>
		
		<view class="">
			--------------------------------------------
		</view>
		<xzj-readMore hideLineNum="2" showHeight="100">
			（这里超出了设置的高度所以显示了查看更多）
			人之初，性本善。性相近，习相远。
			苟不教，性乃迁。教之道，贵以专。
			昔孟母，择邻处。子不学，断机杼。
			窦燕山，有义方。教五子，名俱扬。
			养不教，父之过。教不严，师之惰。
	
		</xzj-readMore>

			--------------------------------------------
		
		<xzj-readMore hideLineNum="9" showHeight="1000">
			<!-- 这里 本身元素高度没有 1000rpx 所以直接导致hideLineNum 失效 -->
			<!--  -->
			（这里超出了设置的高度所以显示了查看更多）
			人之初，性本善。性相近，习相远。
			苟不教，性乃迁。教之道，贵以专。
			昔孟母，择邻处。子不学，断机杼。
			窦燕山，有义方。教五子，名俱扬。
			养不教，父之过。教不严，师之惰。
		</xzj-readMore>
		
	<view class="">
		--------------------------------------------
	</view>
		<xzj-readMore>
		这里高度没有超出设置，所以隐藏了展开
		</xzj-readMore>
	</view>
</template>

<script>
	
</script>

<style scoped lang="scss">
	.main{
		padding: 60rpx;
	}
</style>
